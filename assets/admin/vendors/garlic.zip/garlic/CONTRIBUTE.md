# Contribute!

* fork repository
* `npm install`
* add your changes to garlic.js
* add / update tests to test suite (tests/index.html / tests/tests.js)
* run tests (`npm test`)
* create new minified versions with minify script (see above)
* make a Pull Request!
